package com.capgemini.contactbook.test;
import static org.junit.Assert.*;
import org.junit.Test;
public class ContactBookServiceTest {
	@BeforeClass
	public static void setUp
	@Test
	public void test() {
		fail("Not yet implemented");
	}
}
